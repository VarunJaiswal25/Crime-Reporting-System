<?php
session_start();
header("Location:policelogin.php");
session_destroy();
?>